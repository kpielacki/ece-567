# stepandcalorie
 Step count and calorie calculation with Android Studio
