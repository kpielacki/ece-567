package com.egemenzeytinci.pedometer;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

public class Calorie extends AppCompatActivity {

    private int extra;
    private int notHere = 0;
    private EditText editText, editText2;
    private TextView lenghtText, statusText, weightText, bravoText;
    private SeekBar seekBar;
    private int lenght = 0;
    private int weight = 50;
    private int numSteps = 0;

    private SeekBar.OnSeekBarChangeListener seekBarChangeListener = new SeekBar.OnSeekBarChangeListener(){
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            weight = 50 + progress;
            update();
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            try {
                lenght = Integer.parseInt(s.toString());
            }

            catch (NumberFormatException e) {
                lenght = 0;
            }

            update();
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    private TextWatcher textWatcher2 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            try {
                notHere = Integer.parseInt(s.toString());
            }

            catch (NumberFormatException e) {
                notHere = 0;
            }

            update();
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calorie_main);

        Bundle extras = getIntent().getExtras();
        numSteps = extras.getInt("count");
        extra = extras.getInt("extra");

        editText = (EditText) findViewById(R.id.editText);
        lenghtText = (TextView) findViewById(R.id.length);
        weightText = (TextView) findViewById(R.id.weight);
        statusText = (TextView) findViewById(R.id.status);
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        editText2 = (EditText) findViewById(R.id.editText2);
        bravoText = (TextView) findViewById(R.id.bravo);


        editText.addTextChangedListener(textWatcher);
        editText2.addTextChangedListener(textWatcher2);
        seekBar.setOnSeekBarChangeListener(seekBarChangeListener);

        String sport = getResources().getString(R.string.sport);
        statusText.setText(sport);
        update();

    }

    private void update() {
        weightText.setText(String.valueOf(weight+" kg"));
        lenghtText.setText(String.valueOf(lenght+" cm"));

        String nonStep = getResources().getString(R.string.nonstep);
        String extraString = getResources().getString(R.string.extra);
        String stepString = getResources().getString(R.string.steps);

        double perCm = ((weight*1.256635)/1.609344)/100000;
        double stepLenght = (lenght*42)/100;
        double perStep = perCm*stepLenght;
        double burnCalorie = 0.0;

        if(notHere>0)
            burnCalorie = perStep*(numSteps+notHere);
        else
            burnCalorie = perStep*numSteps;

        if(burnCalorie>=0 && burnCalorie<1)
            statusText.setText(nonStep);

        else if(burnCalorie>=1)
            statusText.setText(String.format("%.2f", burnCalorie)+" cal");

        if(extra>0)
            bravoText.setText(extraString + " " + extra + " " + stepString);
    }
}
