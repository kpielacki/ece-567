package com.egemenzeytinci.pedometer;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class MainActivity extends AppCompatActivity {

/*  private TextView textViewX;
    private TextView textViewY;
    private TextView textViewZ;*/

    private TextView textSensitive;
    private EditText editText;

    private Button textSteps;
    private Button buttonReset;

    private SensorManager sensorManager;
    private float acceleration;

    private float previousY;
    private float currentY;
    private int numSteps;
    private int target = 0;

    private SeekBar seekBar;
    private int threshold;
    private int extra;

    private InterstitialAd mInterstitialAd;

    private TextWatcher targetProcess = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            try {
                target = Integer.parseInt(s.toString());
            }

            catch (NumberFormatException e) {
                target = 0;
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /*textViewX = (TextView) findViewById(R.id.textViewX);
        textViewY = (TextView) findViewById(R.id.textViewY);
        textViewZ = (TextView) findViewById(R.id.textViewZ);*/

        textSteps = (Button) findViewById(R.id.textSteps);
        textSensitive = (TextView) findViewById(R.id.textSensitive);

        buttonReset = (Button) findViewById(R.id.buttonReset);

        seekBar = (SeekBar) findViewById(R.id.seekBar);

        editText = (EditText) findViewById(R.id.editText);

        seekBar.setProgress(10);
        seekBar.setOnSeekBarChangeListener(seekBarListener);
        threshold = 10;
        textSensitive.setText(String.valueOf(threshold));
        editText.addTextChangedListener(targetProcess);

        previousY = 0;
        currentY = 0;
        numSteps = 0;

        acceleration = 0.00f;

        enableAccelerometerListening();

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-1489194755766587/6410198554");
        adLoad();

        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                mInterstitialAd.show();
            }
        });
    }

    private void adLoad() {
        AdRequest adRequest = new AdRequest.Builder().
                build();
        mInterstitialAd.loadAd(adRequest);
    }

    private SensorEventListener sensorEventListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {

            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            currentY = y;

            if(Math.abs(currentY-previousY) > threshold) {
                numSteps++;
                textSteps.setText(String.valueOf(numSteps));

                if(numSteps == target) {
                    String title = getResources().getString(R.string.title);
                    String ticker = getResources().getString(R.string.ticker);
                    String content = getResources().getString(R.string.content);
                    long[] vibrate = {0, 100, 200, 300};

                    NotificationManager notifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                    Notification notify = new Notification.Builder(getApplicationContext()).
                            setTicker(ticker).
                            setContentTitle(title).
                            setContentText(content).
                            setContentIntent(PendingIntent.getActivity(getApplicationContext(), 0, new Intent(getApplicationContext(), Details.class), 0)).
                            setSmallIcon(R.mipmap.cong).
                            setVibrate(vibrate).
                            setAutoCancel(true).
                            getNotification();

                    notifyManager.notify("notify", 0, notify);
                }

            /* textViewX.setText(String.valueOf(x));
            textViewY.setText(String.valueOf(y));
            textViewZ.setText(String.valueOf(z));*/

                previousY = y;
            }

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };

    private SeekBar.OnSeekBarChangeListener seekBarListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            threshold = seekBar.getProgress();
            textSensitive.setText(String.valueOf(threshold));
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };

    private void enableAccelerometerListening() {

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensorManager.registerListener(sensorEventListener, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void resetSteps(View v) {

        numSteps = 0;
        textSteps.setText(String.valueOf(numSteps));
    }

    public void pressed (View v) {

        if(v.getId()==R.id.body) {
            Intent intent = new Intent(getApplicationContext(),BodyMass.class);
            startActivity(intent);
        }

        if(v.getId()==R.id.calorie) {
            extra = numSteps - target;
            Intent intent = new Intent(getApplicationContext(),Calorie.class);
            intent.putExtra("count", numSteps);
            intent.putExtra("extra", extra);
            startActivity(intent);
        }
    }
}
