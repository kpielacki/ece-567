package com.spring.stepcounter.simplestepcounter.constant;

/**
 * Created by fySpring
 * Date : 2017/3/24
 * To do :
 */

public class Constant {
    public static final int MSG_FROM_CLIENT = 0;
    public static final int MSG_FROM_SERVER = 1;

}
